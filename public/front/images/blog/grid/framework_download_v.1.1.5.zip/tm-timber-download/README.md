# ThemeMountain Timber Framework


Repo for ThemeMountain's Timber Framework

It uses Grunt build sys for:
- Css minification
- Image compression
- JS minification

For more information on gruntJS, please visit http://gruntjs.com/

## Installation

To use this project, your computer needs [Node.js](https://nodejs.org/en/) 0.12 or greater.

- Clone this repo
- `npm install` to install the dependencies
   - css min
   - image min
   - jshint
   - nodeunit
   - uglify

